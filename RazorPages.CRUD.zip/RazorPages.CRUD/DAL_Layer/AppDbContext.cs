﻿using Microsoft.EntityFrameworkCore;
using RazorPages.CRUD.Models;

namespace RazorPages.CRUD.DAL_Layer
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }

        protected AppDbContext()
        {
        }

        public DbSet<Product> Products { get; set; }
    }
}
