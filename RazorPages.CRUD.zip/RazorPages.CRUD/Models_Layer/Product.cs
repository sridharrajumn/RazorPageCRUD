﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace RazorPages.CRUD.Models
{
    public class Product
    {
        [Key]
        public int id { get; set; }

        [Required]
        [DisplayName("Product Name")]
        public required string ProductName { get; set; }

        [Required]
        public double Price { get; set; }

        [Required]
        public int Qty { get; set; }
    }
}
